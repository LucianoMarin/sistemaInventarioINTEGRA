<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\Devolucion;
use App\models\Dispositivo;
use App\models\Trabajador;
use App\models\Prestamo;
use Illuminate\Support\Facades\Auth;


class DevolucionController extends Controller
{


    public function index(){
        if(!Auth::check()){
            return redirect('/login');
                }
        try{
        $devolucion = devolucion::all();
        $dispositivo = dispositivo::where('estado','1')->get();
        return view('gestionar_trabajadores.gestionar_trabajador', ['devolucion' => $devolucion , 'dispositivo'=>$dispositivo]); 
        
    }catch(\Illuminate\Database\QueryException $ex){
        return('Error: no se pudo encontrar su conexión con la base de datos');
      }

    }


    public function store(Request $request){

        return null;
    }




    

}
