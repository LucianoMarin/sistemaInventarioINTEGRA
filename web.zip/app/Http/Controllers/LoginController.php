<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Loginrequest;
use Illuminate\Http\Request;

class LoginController extends Controller
{

public function show(){
if(Auth::check()){
return redirect('/principal');
    }
return view('auth.login');
}

public function login(Loginrequest $request){
$credentials=$request->getCredentials();
if(!Auth::validate($credentials)){
return redirect()->to('/login')->withErrors('auth.failed');
}
$user=Auth::getProvider()->retrieveByCredentials($credentials);
Auth::login($user);
return $this->authenticated($request, $user);
}


public function authenticated (Request $request, $user){
return redirect('/principal');
}

}