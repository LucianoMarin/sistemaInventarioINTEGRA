<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\models\Trabajador;
use DB;

class HomeController extends Controller
{

    public function index()
    {
        $trabajador= DB::table('trabajadors')
        ->select('*')    
      ->get();
 

        if(!Auth::check()){
            return redirect('/login');
                }
        return view('main.index', ['trabajador' => $trabajador]);
    }
}
