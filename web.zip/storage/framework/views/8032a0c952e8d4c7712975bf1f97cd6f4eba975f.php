
<?php $__env->startSection('content'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>


<script>
$(document).ready(function() {
  $('#example').DataTable({
    "language": {
      "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
    }
  });
});
    </script>
<form action="<?php echo e(route ('prestamo')); ?>" method="POST">
<div class="contenedor">
<?php echo csrf_field(); ?>
                <div class="container">
                <h1 class="estiloTitulos">Prestamo Equipos</h1>
                    <div class="row">
                   
                    <?php if(session('success')): ?>
                                        <h6 class="alert alert-success"><?php echo e(session('success')); ?></h6>
                                               <?php endif; ?>
                                               <?php if(session('ePk')): ?>
                                               <h6 class="alert alert-danger"><?php echo e(session('ePk')); ?></h6>
                                               <?php endif; ?>
                                               <?php if($errors->any()): ?>
        <div class="container-fluid">
  
           
        <div class="alert alert-danger col-md-12">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <li><?php echo e($error); ?></li>
               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        </div>

        </div>
<?php endif; ?>

                            <div class="col-md-6">
                      
                            <label>Seleccionar Trabajador</label>
                            <br>
                            <select id="trabajador" name="trabajador">
                            <?php $__currentLoopData = $trabajador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($trabajador->rut); ?>"><?php echo e("Nombre: ".$trabajador->nombre." ".$trabajador->apellido_paterno." ".$trabajador->apellido_materno); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                        
                            <label>Seleccionar Dispositivo</label>
                            <br>
                            <select id="dispositivo" name="dispositivo">
                            <?php $__currentLoopData = $dispositivo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dispositivo->serie); ?>">
                        <?php echo e("Tipo: ".$dispositivo->tipo." > Descripcion: ".$dispositivo->marca." ".$dispositivo->modelo." ".$dispositivo->color); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                       
                            <br>

                            </div>
                        
                            
                            <div class="col-md-6">
                            <label>Fecha Prestamo</label>
                            <br>
                            
                            <input type="date" id="fecha_prestamo" name="fecha_prestamo" value="<?php echo date("Y-m-d");?>">
                            <br>
                        <br>
                            <input type="submit" class="btnEstilo" value="Generar">
</form>
</div>
</div>
<br>

<table id="example" class="table  table table-hover" cellspacing="0" width="100%">
<thead>
		<tr>
			<th>RUT TRABAJADOR</th>
			<th>NOMBRE TRABAJADOR</th>
            <th>CODIGO DISPOSITIVO</th>
			<th>NOMBRE DISPOSITIVO</th>
			<th>FECHA PRESTAMOS</th>
			<th>OPCIONES</th>
		</tr>
	</thead>
	<tbody>

        <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<tr>
        <form action="<?php echo e(route ('imprimir')); ?>" method="GET">   
             <td><?php echo e($resultado->rut); ?></td>
			<td><?php echo e($resultado->nombre_trabajador." ".$resultado->segundo_nombre." ".$resultado->apellido_paterno." ".$resultado->apellido_materno); ?></td>
            <td><?php echo e($resultado->serie); ?></td>
            <td><?php echo e($resultado->tipo." ".$resultado->marca." ".$resultado->modelo.""); ?></td>
            <td><?php echo e($resultado->fecha_prestamo); ?></td>
            <td>
            <input type="hidden" value="<?php echo $resultado->tipo_dispositivo?>" name="tipo"> 
            <input type="hidden" value="<?php echo $resultado->marca ?>" name="marca"> 
            <input type="hidden" value="<?php echo $resultado->modelo ?>" name="modelo"> 
            <input type="hidden" value="<?php echo $resultado->color ?>" name="color"> 
            <input type="hidden" value="<?php echo $resultado->serie ?>" name="serie"> 
            <input type="hidden" value="<?php echo $resultado->sim ?>" name="sim"> 
            <input type="hidden" value="<?php echo $resultado->abonado ?>" name="abonado">
            <input type="hidden" value="<?php echo $resultado->nombre_trabajador." ".$resultado->segundo_nombre." ".$resultado->apellido_paterno?>" name="nombreCompleto">
            <input type="hidden" value="<?php echo $resultado->nombre_dependencia ?>" name="nombre_dependencia">
            <input type="hidden" value="<?php echo $resultado->tipos_dependencia ?>" name="tipo_dependencia">
            <input type="hidden" value="<?php echo $resultado->dependencia_tipo ?>" name="departamento">
            <input type="hidden" value="<?php echo $resultado->fecha_prestamo ?>" name="fecha_prestamo">
            <input type="hidden" value="<?php echo $resultado->cargo_fijo ?>" name="cargo_fijo">
          <button type="submit" class="btn bg-info text-white" >
          <img src="image/icon/descargar2.png">
</button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
</div>
        <br>
        <br>
        <br>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('main.pagina_principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\resources\views/gestionar_prestamo/gestionar_prestamo.blade.php ENDPATH**/ ?>