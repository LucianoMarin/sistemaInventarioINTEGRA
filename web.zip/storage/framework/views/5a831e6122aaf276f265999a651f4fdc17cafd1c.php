<?php if(auth()->guard()->check()): ?>
<!DOCTYPE html>
<html lang="en">
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(asset('/js/javascript.js')); ?>"></script>
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
 

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Integra</title>
</head>
<body>
<?php echo $__env->make('nav.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\web\resources\views/main/pagina_principal.blade.php ENDPATH**/ ?>