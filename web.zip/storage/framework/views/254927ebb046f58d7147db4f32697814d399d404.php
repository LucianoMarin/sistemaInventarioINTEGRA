
<nav class="mSuperior navbar-expand-lg shadow mb-2 colorNav">
  <div class="container  container--mega-nav">

  <ul class="navbar">
      <li class="tbaner">
        <img class="banner2" src="image/banner2.png">integra   
    </li>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        
        <li class="nav-item">
  
      
        <li class="nav-item">
        
          <a class="nav-link text-white" href="principal">Inicio</a>
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Gestionar
          </a>
          <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="trabajador">Gestionar trabajador</a></li>
            <li><a class="dropdown-item" href="dispositivo">Gestionar dispositivos</a></li>
            <li><a class="dropdown-item" href="dependencia">Gestionar dependencias</a></li>
    
     
          </ul>
          
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Solicitud
          </a>
          <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="prestamo">Generar prestamo</a></li>
          <li><a class="dropdown-item" href="devolucion">Devoluci&oacuten equipo</a></li>
     
          </ul>
          
        </li>

    
      </ul>

        <ul class="navbar-nav ms-auto flex-nowrap">
          
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Opciones
          </a>
          <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="cambiar_clave">Cambiar Contraseña</a></li>
            <li><a class="dropdown-item" href="">Salir</a></li>
      
            </li> 
          </ul>
    </div>

    </div>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\web\resources\views/nav/nav.blade.php ENDPATH**/ ?>