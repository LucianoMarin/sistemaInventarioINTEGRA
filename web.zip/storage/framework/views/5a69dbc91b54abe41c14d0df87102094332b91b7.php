<div class="modal fade" id="modificarTrabajador<?php echo e($resultado->rut); ?>" tabindex="-1" aria-labelledby="modificar<?php echo e($resultado->rut); ?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modificar Trabajador</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="modal-body">
                                  
<form method="POST" action="<?php echo e(route('trabajador-update', [$resultado->rut])); ?>">      
                             
                                                    <div class="container-fluid">
                                                            <div class="row">
                                                                <div class="cInput">
                                                                <div class="col-md-12">
                                                                </div>
                                                                <div class="col-md-12">
                                                                
                                                                        <div class="row">
                                                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                                    
                                                                                    <label class="atInput">Rut</label>
                                                                                    <br>
                                                                                    <input type="text" id="rut" name="rut" onkeypress="return ValidarInput(event);" disabled="disabled" value="<?php echo e($resultado->rut); ?>">
                                                                                    <br>
                                                                                    <label>Nombre</label>
                                                                                    <br>
                                                                                    <input type="text" id="nombre" name="nombre" onkeypress="return ValidarInput(event);" value="<?php echo e($resultado->trabajador_nombre); ?>">
                                                                                    <br>
                                                                                    <label>Segundo Nombre</label>
                                                                                    <br>
                                                                                    <input type="text" id="s_nombre" name="segundo_nombre" onkeypress="return ValidarInput(event);" value="<?php echo e($resultado->segundo_nombre); ?>" >
                                                                                    <br>
                                                                                    <label>Apellido Paterno</label>
                                                                                    <br>
                                                                                    <input type="text" id="ap_paterno" name="apellido_paterno" onkeypress="return ValidarInput(event);" value="<?php echo e($resultado->apellido_paterno); ?>">
                                                                                    <br>
                                                                                    <label>Apellido Materno</label>
                                                                                    <br>
                                                                                    <input type="text" id="ap_materno" name="apellido_materno" onkeypress="return ValidarInput(event);" value="<?php echo e($resultado->apellido_materno); ?>">
                                                                                    <br>
                                                                                   
                                                                                </div>
                                                                            
                                                                                <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
                                                                                <label>Correo</label>
                                                                                <br>
                                                                                <input class="tmInput" id="correo" name="correo" type="text" onkeypress="return ValidarInput(event);" value="<?php echo e($resultado->correo); ?>">
                                                                                <br>
                                                                                   
                                                                                    <label>Dependencia: </label>
                                                                                    <br>

                                                                                
                                                                                    <select id="dependencia" name="dependencia">
                                                                                    <?php $__currentLoopData = $dependencia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option selected="selected" value="<?php echo e($dependencia->id); ?>"><?php echo e($dependencia->tipo.": ".$dependencia->nombre); ?>

                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                           
                                                                                  <br>
                                                                                    <br>
                                                                                    <br>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                     
                                              
                                                </div>
<br>
<br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <input type="submit" value="Modificar" class="btn btn-primary">
        <?php echo method_field('patch'); ?>   
        <?php echo csrf_field(); ?>
    
</form>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\web\resources\views/gestionar_trabajadores/edit.blade.php ENDPATH**/ ?>