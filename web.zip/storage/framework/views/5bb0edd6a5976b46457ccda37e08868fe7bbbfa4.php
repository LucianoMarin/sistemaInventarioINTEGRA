

<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('title', __('Página no encontrada')); ?>

<?php $__env->startSection('image'); ?>
<style>
    #apartado-derecho{
        text-align:center;
    }
    ul{
        text-decoration: none !important;
        list-style: none;
        color: black;
        font-weight: bold;
    }

    img{
        width:300px;
        margin-top: 30%;
    }
</style>
<div id="apartado-derecho" style="background-color: #bcecf8;" class="absolute pin bg-cover bg-no-repeat md:bg-left lg:bg-center">
 <img src="/image/banner.png">
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('message', __('No hemos encontrado la página que buscas.')); ?>
<?php echo $__env->make('errors::illustrated-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\resources\views/errors/404.blade.php ENDPATH**/ ?>