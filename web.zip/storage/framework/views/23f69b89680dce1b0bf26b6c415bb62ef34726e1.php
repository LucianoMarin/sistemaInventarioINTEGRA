
<?php $__env->startSection('content'); ?>


<div class="contenedor">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2">
                </div>
                <div class="col-md-8">
                    <h1 class="estiloTitulos">Cambiar Contraseña</h1>
                    <div class="container-fluid">
                        <div class="row">
                   
                                <br>
                            <label>Usuario: </label>
                            <input type="text" disabled>   
                            <br>
                            <label>Nueva Contraseña: </label>
                            <input type="text"> 
                            <br>
                            <label>Validar Contraseña: </label>
                            <input type="text">     


                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <br>
        <br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.pagina_principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\resources\views/perfil/cambiar_clave.blade.php ENDPATH**/ ?>