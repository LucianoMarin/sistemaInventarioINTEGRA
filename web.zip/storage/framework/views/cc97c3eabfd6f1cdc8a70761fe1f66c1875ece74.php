
<?php $__env->startSection('content'); ?>


<div class="contenedor">

                <div class="container">
                <h1 class="estiloTitulos">Devolucion Equipos</h1>
                    <div class="row">
                        
                   
                            <div class="col-md-6">
                            <label>Buscar por:</label>
                            <br>
                         
                            <label>Rut</lable>
                            <input type="radio" id="opciones" name="opciones" value="rut">
                            <br>
                            <label>Correo</lable>
                            <input type="radio" id="opciones2" name="opciones" value="correo">
                            <br>
                             <div id="brut" name="brut"></div>
                             <div id="bcorreo" name="bcorreo"></div>

                             <script>
$(document).ready(function()
		{
		$("#opciones").click(function () {	 


			($('input:radio[name=opciones]:checked').val());

                        $('#brut').html('<label>RUT: </label><br><input type="text" name="color" id="color" onkeypress="return ValidarInput(event);"> <input type="submit" class="btn btn-primary" value="Buscar">').show();
                        $('#bcorreo').html('<label>Color </label><br><input type="hidden" name="color" id="color" onkeypress="return ValidarInput(event);">').hide();

                });

                        $("#opciones2").click(function () {	 
			($('input:radio[name=opciones]:checked').val());
                        $('#bcorreo').html('<label>CORREO: </label><br><input type="text" name="color" id="color" onkeypress="return ValidarInput(event);"> <input type="submit" class="btn btn-primary" value="Buscar">').show();
                        $('#brut').html('<label>Color </label><br><input type="hidden" name="color" id="color" onkeypress="return ValidarInput(event);">').hide();

			});

                

		 });


                             </script>




                            <div class="col-md-6">
</div>
                       
</div>
</div>
</div>
        <br>
        <br>
        <br>
  
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('main.pagina_principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\resources\views/gestionar_prestamo/gestionar_devolucion.blade.php ENDPATH**/ ?>