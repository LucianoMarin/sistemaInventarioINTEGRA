
<?php $__env->startSection('content'); ?>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>


<script>
 $(document).ready(function() {
  $('#example').DataTable({
    "language": {
      "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
    }
  });
});
    </script>



    <div class="contenedor">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2">
                </div>
                <div class="col-md-8">
                    <h1 class="estiloTitulos">Gestionar Dispositivo</h1>
                    <div class="container-fluid">
                        <div class="row">
                        
                                <div class="col-md-12">
                                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal" data-bs-whatever="@mdo" onclick="limpiar()">Ingresar
                                        Dispositivos</button>
                               
                                        <?php if(session('success')): ?>
                                        <h6 class="alert alert-success"><?php echo e(session('success')); ?></h6>
                                               <?php endif; ?>
                                               <?php if(session('ePk')): ?>
                                               <h6 class="alert alert-danger"><?php echo e(session('ePk')); ?></h6>
                                               <?php endif; ?>
                                              <?php if($errors->any()): ?>
      
           
        <div class="alert alert-danger col-md-12">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <li><?php echo e($error); ?></li>
               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
        </div>

<?php endif; ?>

                                        

                                    <div class="modal fade" id="exampleModal" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="estiloTitulos" id="exampleModalLabel">INGRESAR DISPOSITIVO
                                                    </h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Cerrar"></button>
                                                        
                                                </div>
                                                
                                                <div class="modal-body">
                                                <form action="<?php echo e(route ('dispositivo')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                        <div class="container-fluid">
                                                            <div class="row">
                                                                <div class="cInput">
                                                                <div class="col-md-12">
                                                                </div>
                                                                <div class="col-md-12">

                                                                        <div class="row">
                                                                                <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
                                                                                <label>Tipo</label>
                                                                                    <br>
                                                                                    <select id="dispositivos" name="dispositivos" >
                                                                                        <option selected="selected" value="Computador">Computador</option>
                                                                                        <option value="Notebook">Notebook</option>
                                                                                        <option value="Celular">Celular</option>
                                                                                        <option value="Otros">Otros</option>
                                                                                    </select>
                                                                                    <br>
                                                                               
                                                                                    <label>S/N o IMEI</label>
                                                                                    <br>
                                                                                    <input type="text" name="cod" id="cod" onkeypress="return ValidarInput(event);"">
                                                                                    <br>
                                                                    
                                                                                   
                                                                                  
                                                              
                                                                                </div>
                                                                            
                                                                                <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
                                                                          
                                                                                <label>Marca</label>
                                                                                    <br>
                                                                                    <input type="text" name="marca" id="marca">
                                                                                    <br>

                                                                                <label>Modelo</label>
                                                                                    <br>
                                                                                    
                                                                                    <input type="text" name="modelo"  id="modelo" >
                                                                                    <br>
                                                                                    <label>Color</label>
                                                                                    <br>
                                                                                    
                                                                                    <input type="text" name="color"  id="color" onkeypress="return ValidarInput(event);" >
                                                                                    <br>
                                                                              
                                                                                    <div id="color" name="color"></div>
                                                                                    <div id="sim" name="sim"></div>
                                                                                    <div id="abonado" name="abonado"></div>
                                                                                    <div id="activo_fijo" name="activo_fijo"></div>
                                                                                
                                                                                
 <script>
$(document).on('change', '#dispositivos', function(event) {
       if(($("#dispositivos option:selected").text())=="Celular"){
        $('#sim').html('<label>Sim </label><br><input type="text" name="sim" id="sim" onkeypress="return ValidarInput(event);">');
        $('#abonado').html('<label>Abonado</label><br><input type="text" name="abonado" id="abonado" onkeypress="return ValidarInput(event);">');
        $('#activo_fijo').html('<label>Activo Fijo</label><br><input type="text" name="actiivo_fijo" id="actiivo_fijo" onkeypress="return ValidarInput(event);">').hide();   
    }
       else{
        $('#sim').html("");
        $('#abonado').html("");
        $('#activo_fijo').html('<label>Activo Fijo</label><br><input type="text" name="activo_fijo" id="activo_fijo" onkeypress="return ValidarInput(event);">').show();
       }
   });

</script>




                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                     
                                                
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Cerrar</button>
                                                        <input type="submit" class="btn btn-primary" value="Enviar">
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        
                                </div>

                            
<table id="example" class="table  table table-hover " cellspacing="0" width="100%">
	<thead>
		<tr>
			<th>CODIGO</th>
            <th>TIPO</th>
            <th>MARCA</th>
			<th>MODELO</th>
			<th>COLOR</th>
            <th>SIM</th>
            <th>ABONADO</th>
            <th>FIJO</th>
            <th>OPCIONES</th>
		</tr>
	</thead>
	<tbody>
        

    <?php $__currentLoopData = $dispositivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispositivos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


		<tr>
			<td><?php echo e($serie=$dispositivos->serie); ?></td>
			<td><?php echo e($dispositivos->tipo); ?></td>
			<td><?php echo e($dispositivos->marca); ?></td>
			<td><?php echo e($dispositivos->modelo); ?></td>
            <td><?php echo e($dispositivos->color); ?></td>
            <td><?php echo e($dispositivos->sim); ?></td>
            <td><?php echo e($dispositivos->abonado); ?></td> 
            <td><?php echo e($dispositivos->cargo_fijo); ?></td> 
            <td>
                
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" id="bmodificar" data-bs-target="#modificarDispositivo<?php echo e($serie); ?>"  data-target="#modificarDispositivo<?php echo e($serie); ?>" onclick="showInp()">
 Modificar

</button>
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#eliminarDispositivo<?php echo e($serie); ?>" data-target="#eliminarDispositivo<?php echo e($serie); ?>">
  Eliminar
</button>

<?php echo $__env->make('gestionar_dispositivo.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    


<script>


$("#modificarDispositivo<?php echo e($serie); ?>").on('change', '.dispositivos2', function(ev) {
  
  if(($("#modificarDispositivo<?php echo e($serie); ?> .dispositivos2 option:selected").text())=="Celular"){
        $('.campo2').html('<label>Sim </label><br><input type="text" name="sim2" class="sim2" onkeypress="return ValidarInput(event);">').show();
        $('.campo3').html('<label>Abonado</label><br><input type="text" name="abonado2" class="abonado2" onkeypress="return ValidarInput(event);">').show();
        $('.campo4').html('<label>Activo Fijo</label><br><input type="text" name="activo_fijo2" classs="activo_fijo2" onkeypress="return ValidarInput(event);">').hide();   
   
    }
    else{
        $('.campo2').html("");
        $('.campo3').html("");
        $('.campo4').html('<label>Activo Fijo</label><br><input type="text" name="activo_fijo2" id="activo_fijo" onkeypress="return ValidarInput(event);">').show();
 
    }
 
});



        </script>
</td>


<!-- Modal -->

        
<div class="modal fade" id="eliminarDispositivo<?php echo e($serie); ?>" tabindex="-1" aria-labelledby="eliminar<?php echo e($serie); ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar Dispositivo</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      Esta seguro que desea eliminar el Dispositivo:
      <br>
      <br>
      <label> <?php echo e("Codigo: ".$dispositivos->serie); ?></label>
      <br>
      <label> <?php echo e("Tipo: ".$dispositivos->tipo); ?></label>
      <br>
      <label><?php echo e("Marca: ".$dispositivos->marca); ?></label>
      <br>
      <label><?php echo e("Modelo: ".$dispositivos->modelo); ?></label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <form method="POST" action="<?php echo e(route('dispositivo-destroy', [$dispositivos->serie])); ?>">
        <input type="submit" value="Eliminar" class="btn btn-primary" >
  <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            </form>

      </div>
    </div>
  </div>
  </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</tr>
  

	</tbody>
</table>
</div>
</div>
</div>
        </div>
        <br>
        <br>
        <br>
     
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.pagina_principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\resources\views/gestionar_dispositivo/gestionar_dispositivo.blade.php ENDPATH**/ ?>