
<?php $__env->startSection('content'); ?>

<div class="contenedor">
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>


<script>
 $(document).ready(function() {
  $('#example').DataTable({
    "language": {
      "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
    }
  });
});
    </script>

    <div class="contenedor">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2">
                </div>
                <div class="col-md-8">
                    <h1 class="estiloTitulos">Gestionar Dependencias</h1>
                    <div class="container-fluid">
                        <div class="row">
                        
                                <div class="col-md-12">
                                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal" data-bs-whatever="@mdo" onclick="">Ingresar
                                        Dependencia</button>
                               
                                        <?php if(session('success')): ?>
                                        <h6 class="alert alert-success"><?php echo e(session('success')); ?></h6>
                                               <?php endif; ?>
                                               <?php if(session('ePk')): ?>
                                               <h6 class="alert alert-danger"><?php echo e(session('ePk')); ?></h6>
                                               <?php endif; ?>
                                               <?php if($errors->any()): ?>
   
           
        <div class="alert alert-danger col-md-12">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

                                        

                                    <div class="modal fade" id="exampleModal" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="estiloTitulos" id="exampleModalLabel">INGRESAR DEPENDENCIA
                                                    </h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Cerrar"></button>
                                                        
                                                </div>
                                                
                                                <div class="modal-body">
                                                <form action="<?php echo e(route('dependencia')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                        <div class="container-fluid">
                                                            <div class="row">
                                                                <div class="cInput">
                                                                <div class="col-md-12">
                                                                </div>
                                                                <div class="col-md-12">

                                                                        <div class="row">
                                                                                <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
                                                                                <label>Tipo</label>
                                                                                    <br>
                                                                          
                                                                                    <select id="tipo" name="tipo" >
                                                                                        <option selected="selected" value="Departamento">Departamento</option>
                                                                                        <option value="Jardín Infantil">Jardín Infantil</option>
                                                                                    </select>
                                                                                    
                                                                                    <br>
                                                              
                                                                                </div>
                                                                            
                                                                                <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
                                                                          
                                                                                <label>Nombre</label>
                                                                                    <br>
                                                                                    <input type="text" name="nombre" id="nombre" required="required" >
                                                                                    <br>
          

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                     
                                                
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Cerrar</button>
                                                        <input type="submit" class="btn btn-primary" value="Enviar">
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        
                                </div>
          
<table id="example" class="table  table table-hover " cellspacing="0" width="100%">
	<thead>
		<tr>
			<th>TIPO</th>
            <th>NOMBRE</th>
            <th>OPCIONES</th>
		</tr>
     
	</thead>
	<tbody>

    <?php $__currentLoopData = $dependencia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
		<tr>
            
  
			<td><?php echo e($dependencia->tipo); ?></td>
			<td><?php echo e($dependencia->nombre); ?></td>
            <td>
                
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modificarDependencia<?php echo e($dependencia->id); ?>" data-target="#modificarDependencia<?php echo e($dependencia->id); ?>" >
 Modificar

</button>
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#eliminarDependencia<?php echo e($dependencia->id); ?>" data-target="#eliminarDependencia<?php echo e($dependencia->id); ?>">
  Eliminar
</button>
 
<?php echo $__env->make('gestionar_dependencias.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</td>


<!-- Modal -->

<div class="modal fade" id="eliminarDependencia<?php echo e($dependencia->id); ?>" tabindex="-1" aria-labelledby="eliminar" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar Dependencia</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      Esta seguro que desea eliminar la Dependencia:
      <br>
      <label><?php echo e("Tipo: ".$dependencia->tipo); ?></label>
      <br>
      <label><?php echo e("Nombre: ".$dependencia->nombre); ?></label>
      <br>
      <br>
      <h6></h6>
      <h6></h6>
      <h6></h6>
      <h6></h6>
      </div>
   

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <form method="POST" action="<?php echo e(route('dependencia-destroy', [$dependencia->id])); ?>">
        <input type="submit" value="Eliminar" class="btn btn-primary" >
  <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  </div>



            	
		</tr>
   

	</tbody>
</table>
</div>
</div>
</div>
        </div>
        <br>
        <br>
        <br>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.pagina_principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web\resources\views/gestionar_dependencias/gestionar_dependencias.blade.php ENDPATH**/ ?>