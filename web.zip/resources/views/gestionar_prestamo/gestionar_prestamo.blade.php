@extends('main.pagina_principal')
@section('content')
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>


<script>
$(document).ready(function() {
  $('#example').DataTable({
    "language": {
      "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
    }
  });
});
    </script>
<form action="{{route ('prestamo')}}" method="POST">
<div class="contenedor">
@csrf
                <div class="container">
                <h1 class="estiloTitulos">Prestamo Equipos</h1>
                    <div class="row">
                   
                    @if (session('success'))
                                        <h6 class="alert alert-success">{{ session('success') }}</h6>
                                               @endif
                                               @if(session('ePk'))
                                               <h6 class="alert alert-danger">{{ session('ePk') }}</h6>
                                               @endif
                                               @if ($errors->any())
        <div class="container-fluid">
  
           
        <div class="alert alert-danger col-md-12">
            @foreach ($errors->all() as $error)
            
            <li>{{ $error }}</li>
               
            @endforeach
      
        </div>

        </div>
@endif

                            <div class="col-md-6">
                      
                            <label>Seleccionar Trabajador</label>
                            <br>
                            <select id="trabajador" name="trabajador">
                            @foreach($trabajador as $trabajador)
                            <option value="{{$trabajador->rut}}">{{"Nombre: ".$trabajador->nombre." ".$trabajador->apellido_paterno." ".$trabajador->apellido_materno}}</option>
                            @endforeach
                        </select>
                        <br>
                        
                            <label>Seleccionar Dispositivo</label>
                            <br>
                            <select id="dispositivo" name="dispositivo">
                            @foreach($dispositivo as $dispositivo)
                            <option value="{{$dispositivo->serie}}">
                        {{"Tipo: ".$dispositivo->tipo." > Descripcion: ".$dispositivo->marca." ".$dispositivo->modelo." ".$dispositivo->color}}
                            </option>
                            @endforeach
                            </select>
                       
                            <br>

                            </div>
                        
                            
                            <div class="col-md-6">
                            <label>Fecha Prestamo</label>
                            <br>
                            
                            <input type="date" id="fecha_prestamo" name="fecha_prestamo" value="<?php echo date("Y-m-d");?>">
                            <br>
                        <br>
                            <input type="submit" class="btnEstilo" value="Generar">
</form>
</div>
</div>
<br>

<table id="example" class="table  table table-hover" cellspacing="0" width="100%">
<thead>
		<tr>
			<th>RUT TRABAJADOR</th>
			<th>NOMBRE TRABAJADOR</th>
            <th>CODIGO DISPOSITIVO</th>
			<th>NOMBRE DISPOSITIVO</th>
			<th>FECHA PRESTAMOS</th>
			<th>OPCIONES</th>
		</tr>
	</thead>
	<tbody>

        @foreach($resultado as $resultado)

		<tr>
        <form action="{{route ('imprimir')}}" method="GET">   
             <td>{{$resultado->rut}}</td>
			<td>{{$resultado->nombre_trabajador." ".$resultado->segundo_nombre." ".$resultado->apellido_paterno." ".$resultado->apellido_materno}}</td>
            <td>{{$resultado->serie}}</td>
            <td>{{$resultado->tipo." ".$resultado->marca." ".$resultado->modelo.""}}</td>
            <td>{{$resultado->fecha_prestamo}}</td>
            <td>
            <input type="hidden" value="<?php echo $resultado->tipo_dispositivo?>" name="tipo"> 
            <input type="hidden" value="<?php echo $resultado->marca ?>" name="marca"> 
            <input type="hidden" value="<?php echo $resultado->modelo ?>" name="modelo"> 
            <input type="hidden" value="<?php echo $resultado->color ?>" name="color"> 
            <input type="hidden" value="<?php echo $resultado->serie ?>" name="serie"> 
            <input type="hidden" value="<?php echo $resultado->sim ?>" name="sim"> 
            <input type="hidden" value="<?php echo $resultado->abonado ?>" name="abonado">
            <input type="hidden" value="<?php echo $resultado->nombre_trabajador." ".$resultado->segundo_nombre." ".$resultado->apellido_paterno?>" name="nombreCompleto">
            <input type="hidden" value="<?php echo $resultado->nombre_dependencia ?>" name="nombre_dependencia">
            <input type="hidden" value="<?php echo $resultado->tipos_dependencia ?>" name="tipo_dependencia">
            <input type="hidden" value="<?php echo $resultado->dependencia_tipo ?>" name="departamento">
            <input type="hidden" value="<?php echo $resultado->fecha_prestamo ?>" name="fecha_prestamo">
            <input type="hidden" value="<?php echo $resultado->cargo_fijo ?>" name="cargo_fijo">
          <button type="submit" class="btn bg-info text-white" >
          <img src="image/icon/descargar2.png">
</button>
</form>
@endforeach

</table>
</div>
        <br>
        <br>
        <br>

        @endsection