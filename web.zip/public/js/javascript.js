
     function ValidarInput(evt){
    

            if (evt.which == 32){
                return false;
            }
     
     }


     function limpiar(){

        document.getElementById("cod").value = "";
        document.getElementById("modelo").value = "";
        document.getElementById("color").value = "";
        document.getElementById("sim").value = "";
        document.getElementById("abonado").value = "";
        document.getElementById("dispositivos").value = "";
        document.getElementById("marca").value = "";

     }

     function limpiarTrabajador(){

        document.getElementById("rut").value = "";
        document.getElementById("nombre").value = "";
        document.getElementById("s_nombre").value = "";
        document.getElementById("a_paterno").value = "";
        document.getElementById("a_materno").value = "";
        document.getElementById("departamento").value = "";
        document.getElementById("correo").value = "";
 
     }


     




 function validarNumero(evt){
 
   if (evt.which == 32  || evt.keyCode   > 31 && (evt.keyCode  < 45 || evt.keyCode  > 57 && evt.keyCode!=75 && evt.keyCode!=107 ) ){
      return false;
        
  }






}


 